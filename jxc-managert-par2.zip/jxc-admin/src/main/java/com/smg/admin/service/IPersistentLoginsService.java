package com.smg.admin.service;

import com.smg.admin.pojo.PersistentLogins;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
public interface IPersistentLoginsService extends IService<PersistentLogins> {

}
