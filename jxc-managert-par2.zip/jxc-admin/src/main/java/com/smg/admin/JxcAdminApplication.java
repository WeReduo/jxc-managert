package com.smg.admin; /**
 * Project Name: jxc-managert-par2
 * File Name: com.smg.admin.JxcAdminApplication
 *
 * @version 1.0
 * @author:wenerduo
 * @Date: 2022/04/04/上午 10:30
 * Copyright (c) 2022,
 */

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动类
 *
 * @author bitaotao
 * @version 1.0
 */
@SpringBootApplication
@MapperScan("com.smg.admin.mapper")
public class JxcAdminApplication {

    public static void main(String[] args) {
        SpringApplication.run(JxcAdminApplication.class,args);

    }
}
