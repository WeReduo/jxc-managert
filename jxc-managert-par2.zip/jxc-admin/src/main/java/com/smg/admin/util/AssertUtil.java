package com.smg.admin.util;


import com.smg.admin.exceptions.ParamsException;

/**
 * @author bitaotao
 * @version 1.0
 */
public class AssertUtil {


    public  static void isTrue(Boolean flag,String msg){
        if(flag){
            throw  new ParamsException(msg);
        }
    }

}
