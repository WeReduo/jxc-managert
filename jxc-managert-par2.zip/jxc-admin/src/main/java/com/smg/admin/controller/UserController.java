package com.smg.admin.controller;


import com.smg.admin.exceptions.ParamsException;
import com.smg.admin.model.RespBean;
import com.smg.admin.pojo.User;
import com.smg.admin.service.IUserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
@Controller
@RequestMapping("/user")
public class UserController {
    @Resource
    private IUserService userService;
    @RequestMapping("login")
    @ResponseBody
    public RespBean Login(String userName, String passWord, HttpSession session){
        try {
            User user=userService.Login(userName,passWord);
            session.setAttribute("user",user);
            return  RespBean.success("用户登陆成功",user);
            
        }catch (ParamsException e){
            e.printStackTrace();

            e.printStackTrace();
            return RespBean.error(e.getMsg());
        } catch (Exception e) {
            e.printStackTrace();
            return RespBean.error("用户登录失败");
        }
    }
    
}
