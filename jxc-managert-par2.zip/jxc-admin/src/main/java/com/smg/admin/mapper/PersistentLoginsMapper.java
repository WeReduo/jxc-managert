package com.smg.admin.mapper;

import com.smg.admin.pojo.PersistentLogins;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author bitaotao
 * @since 2021-09-12
 */
public interface PersistentLoginsMapper extends BaseMapper<PersistentLogins> {

}
