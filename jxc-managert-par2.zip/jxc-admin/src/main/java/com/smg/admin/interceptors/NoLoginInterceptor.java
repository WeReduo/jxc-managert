package com.smg.admin.interceptors;

import com.smg.admin.pojo.User;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 未登录情况下，需执行的拦截器
 * @author bitaotao
 * @since 2021-09-12
 */
public class NoLoginInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        User user = (User) request.getSession().getAttribute("user");
        if(null == user){
            // 重定向到首页
            response.sendRedirect("index");
            return false;
        }
        return true;
    }
}
