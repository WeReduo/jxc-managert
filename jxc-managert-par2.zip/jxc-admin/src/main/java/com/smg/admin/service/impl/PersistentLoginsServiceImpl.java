package com.smg.admin.service.impl;

import com.smg.admin.pojo.PersistentLogins;
import com.smg.admin.mapper.PersistentLoginsMapper;
import com.smg.admin.service.IPersistentLoginsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author bitaotao
 * @since 2021-09-12
 */
@Service
public class PersistentLoginsServiceImpl extends ServiceImpl<PersistentLoginsMapper, PersistentLogins> implements IPersistentLoginsService {

}
