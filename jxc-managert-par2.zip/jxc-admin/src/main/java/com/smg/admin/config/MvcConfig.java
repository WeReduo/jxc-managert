package com.smg.admin.config;

import com.smg.admin.interceptors.NoLoginInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * mvc配置类
 * @author bitaotao
 * @since 2021-09-12
 */
@Configuration
public class MvcConfig extends WebMvcConfigurerAdapter {

    @Bean
    public NoLoginInterceptor noLoginInterceptor(){
        return new NoLoginInterceptor();
    }
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(noLoginInterceptor())
                .addPathPatterns("/**") // 拦截所有资源
                .excludePathPatterns("/index","/user/login", // 放开首页、登录请求
                        "/css/**","/error/**","/images/**","/js/**","/lib/**");// 放开静态资源
    }
}
