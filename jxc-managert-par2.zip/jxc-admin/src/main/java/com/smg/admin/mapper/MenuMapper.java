package com.smg.admin.mapper;

import com.smg.admin.pojo.Menu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 菜单表 Mapper 接口
 * </p>
 *
 * @author bitaotao
 * @since 2021-09-11
 */
public interface MenuMapper extends BaseMapper<Menu> {

}
