package com.smg.admin.mapper;

import com.smg.admin.pojo.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author bitaotao
 * @since 2021-09-11
 */
public interface UserMapper extends BaseMapper<User> {

}
