package com.smg.admin.service;

import com.smg.admin.pojo.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 菜单表 服务类
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
public interface IMenuService extends IService<Menu> {

}
