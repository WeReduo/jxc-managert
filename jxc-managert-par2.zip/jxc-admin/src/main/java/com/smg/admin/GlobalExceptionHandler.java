package com.smg.admin;

import com.smg.admin.exceptions.ParamsException;
import com.smg.admin.model.RespBean;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 全局异常处理器。
 * 一般情况下，在service层会产生异常，然后抛给了controller层
 * @author bitaotao
 * @version 1.0
 */
@ControllerAdvice
public class GlobalExceptionHandler {
    /**
     * 自定义参数异常处理
     * @param e 自定义参数异常对象
     * @return
     */
    @ExceptionHandler(ParamsException.class)
    @ResponseBody
    public RespBean paramsExceptionHandler(ParamsException e){
        // e.getMsg() 自定义异常信息
        return RespBean.error(e.getMsg());
    }

    /**
     * 系统内异常处理
     * @param e 系统内异常对象
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public RespBean exceptionHandler(Exception e){
        // e.getMessage() 系统自带异常信息
        return RespBean.error(e.getMessage());
    }
}
