package com.smg.admin.service;

import com.smg.admin.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
public interface IUserService extends IService<User> {
    /**
     * 用户登录方法
     * @param userName 用户名
     * @param passWord 密码
     * @return
     */
    User Login(String userName, String passWord);

    /**
     * 根据用户名查询用户记录
     * @param userName 用户名
     * @return
     */
    public User findUserByUserName(String userName);

}
