package com.smg.admin.service;

import com.smg.admin.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author bitaotao
 * @since 2021-09-11
 */
public interface IUserService extends IService<User> {
    /**
     * 用户登录方法
     * @param userName 用户名
     * @param passWord 密码
     * @return
     */
    User login(String userName, String passWord);

    /**
     * 根据用户名查询用户记录
     * @param userName 用户名
     * @return
     */
    public User findUserByUserName(String userName);

    /**
     * 用户信息更新
     * @param user 用户对象
     */
    void updateUserInfo(User user);

    /***
     * 更新用户密码
     * @param userName 用户名
     * @param oldPassword 旧密码
     * @param newPassword 新密码
     * @param confirmPassword 确认密码
     */
    void updateUserPassword(String userName, String oldPassword, String newPassword, String confirmPassword);
}
