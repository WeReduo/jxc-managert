package com.smg.admin.service;

import com.smg.admin.pojo.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户角色表 服务类
 * </p>
 *
 * @author bitaotao
 * @since 2021-09-11
 */
public interface IUserRoleService extends IService<UserRole> {

}
