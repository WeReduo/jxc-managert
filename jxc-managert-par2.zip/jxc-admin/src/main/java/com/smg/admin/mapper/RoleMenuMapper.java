package com.smg.admin.mapper;

import com.smg.admin.pojo.RoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色菜单表 Mapper 接口
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
public interface RoleMenuMapper extends BaseMapper<RoleMenu> {

}
