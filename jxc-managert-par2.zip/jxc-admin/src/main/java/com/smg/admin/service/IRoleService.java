package com.smg.admin.service;

import com.smg.admin.pojo.Role;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
public interface IRoleService extends IService<Role> {

}
