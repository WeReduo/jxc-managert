package com.smg.admin.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author bitaotao
 * @since 2021-09-12
 */
@Controller
@RequestMapping("/persistent-logins")
public class PersistentLoginsController {

}
