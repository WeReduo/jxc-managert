package com.smg.admin.service.impl;

import com.smg.admin.pojo.Role;
import com.smg.admin.mapper.RoleMapper;
import com.smg.admin.service.IRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 角色表 服务实现类
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements IRoleService {

}
