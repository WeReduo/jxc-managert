package com.smg.admin.service;

import com.smg.admin.pojo.RoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色菜单表 服务类
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
public interface IRoleMenuService extends IService<RoleMenu> {

}
