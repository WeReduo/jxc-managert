package com.smg.admin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.smg.admin.pojo.User;
import com.smg.admin.mapper.UserMapper;
import com.smg.admin.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.smg.admin.util.AssertUtil;
import com.smg.admin.util.StringUtil;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author bitaotao
 * @since 2022-04-04
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {


    /**
     * 用户登录方法
     *
     * @param userName 用户名
     * @param passWord 密码
     * @return
     */
    @Override
    public User Login(String userName, String passWord) {
        AssertUtil.isTrue(StringUtil.isEmpty(userName),"用户名不能为空!");
        AssertUtil.isTrue(StringUtil.isEmpty(passWord),"密码名不能为空!");
        User user = this.findUserByUserName(userName);
        AssertUtil.isTrue(null == user,"该用户记录不存在或已注销!");
        /**
         * 后续引入SpringSecurity 使用框架处理密码
         */
        AssertUtil.isTrue(!(user.getPassword().equals(passWord)),"密码错误!");
        return user;
    }

    /**
     * 根据用户名查询用户记录
     *
     * @param userName 用户名
     * @return
     */
    @Override
    public User findUserByUserName(String userName) {
        return this.baseMapper.selectOne(new QueryWrapper<User>().eq("is_del",0).eq("user_name",userName));
    }
}
